// SVDlibrary.h

void ProcessData(char* datafile, char* resultnameblock);